<?php

return [
    'api_key' => '0d707ba956c700912d77716a2aa59e6a',    // visit: http://openweathermap.org/appid#get for more info.
    'routes_enabled' => true,   // If the routes have to be enabled.
];
